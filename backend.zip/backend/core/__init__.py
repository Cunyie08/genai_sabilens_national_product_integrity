"""Core utilities and middleware"""
