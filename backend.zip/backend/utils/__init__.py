"""Utils init"""
